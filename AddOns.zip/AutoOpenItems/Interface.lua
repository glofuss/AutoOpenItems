


local mainoptionframe = CreateFrame("Frame")
local texture = mainoptionframe:CreateTexture(nil, "BACKGROUND")
